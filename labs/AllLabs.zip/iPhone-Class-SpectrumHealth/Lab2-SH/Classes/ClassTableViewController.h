//
//  ClassTableViewController.h
//  Lab2-SH
//
//  Created by Chris Zelenak on 10/4/10.
//  Copyright 2010 Fastest Forward. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ClassTableViewController : UITableViewController {
	NSArray * people;
}

@end
