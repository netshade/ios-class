//
//  Lab2_SHViewController.h
//  Lab2-SH
//
//  Created by Chris Zelenak on 10/4/10.
//  Copyright 2010 Fastest Forward. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab2_SHViewController : UIViewController {

}

-(IBAction) openNewController:(id) sender;

@end

