//
//  Lab1_SHViewController.h
//  Lab1-SH
//
//  Created by Chris Zelenak on 10/4/10.
//  Copyright 2010 Fastest Forward. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab1_SHViewController : UIViewController {
	NSInteger foo		;
}

-(IBAction) helloWorld:(id)sender;

@end

