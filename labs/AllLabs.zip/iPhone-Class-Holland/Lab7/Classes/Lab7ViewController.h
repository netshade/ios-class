//
//  Lab7ViewController.h
//  Lab7
//
//  Created by Chris Zelenak on 6/21/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab7ViewController : UIViewController {

}

-(IBAction) openSecondController:(id)sender;

@end

