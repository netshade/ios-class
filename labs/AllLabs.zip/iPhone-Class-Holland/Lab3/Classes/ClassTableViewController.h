//
//  ClassTableViewController.h
//  Lab3
//
//  Created by Chris Zelenak on 6/21/10.
//  Copyright 2010 Fastest Forward. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ClassTableViewController : UITableViewController {
	NSArray * items;
}

@end
