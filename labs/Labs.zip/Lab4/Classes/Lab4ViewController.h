//
//  Lab4ViewController.h
//  Lab4
//
//  Created by Chris Zelenak on 6/21/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab4ViewController : UIViewController {

}

-(IBAction) openSecondController:(id)sender;

@end

