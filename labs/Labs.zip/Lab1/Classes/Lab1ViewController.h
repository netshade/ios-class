//
//  Lab1ViewController.h
//  Lab1
//
//  Created by Chris Zelenak on 6/20/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab1ViewController : UIViewController {

}

-(IBAction) openAlertView:(id)sender;

@end

