//
//  Lab3ViewController.h
//  Lab3
//
//  Created by Chris Zelenak on 6/21/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab3ViewController : UIViewController {

}

-(IBAction) openSecondController:(id)sender;

@end

