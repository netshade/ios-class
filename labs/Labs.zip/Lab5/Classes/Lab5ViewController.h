//
//  Lab5ViewController.h
//  Lab5
//
//  Created by Chris Zelenak on 6/21/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab5ViewController : UIViewController {

}

-(IBAction) openSecondController:(id)sender;

@end

