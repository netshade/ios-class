//
//  Lab2ViewController.h
//  Lab2
//
//  Created by Chris Zelenak on 6/22/10.
//  Copyright Fastest Forward 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab2ViewController : UIViewController {
	
}

-(IBAction) openOtherViewController:(id)sender;

@end

